const express = require("express");
const store = require("../store");

const router = express.Router();

// FR-7.1: register as Farmer, Buyer, Market Seller, or Transport Provider
router.post("/", (req, res) => {
  const { name, phone, role, location } = req.body;
  if (!name || !phone || !role) {
    return res.status(400).json({ error: "name, phone, and role are required" });
  }
  const validRoles = ["farmer", "buyer", "market_seller", "transporter", "admin"];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ error: `role must be one of ${validRoles.join(", ")}` });
  }
  if (store.findUserByPhone(phone)) {
    return res.status(409).json({ error: "a user with this phone number already exists" });
  }
  const user = store.createUser({ name, phone, role, location });
  res.status(201).json(user);
});

router.get("/", (req, res) => {
  res.json(store.listUsers());
});

router.get("/:id", (req, res) => {
  const user = store.getUser(req.params.id);
  if (!user) return res.status(404).json({ error: "user not found" });
  res.json(user);
});

// FR-7.3: rate a counterparty after a completed transaction
router.post("/:id/rate", (req, res) => {
  const { score } = req.body;
  if (typeof score !== "number" || score < 1 || score > 5) {
    return res.status(400).json({ error: "score must be a number between 1 and 5" });
  }
  const user = store.rateUser(req.params.id, score);
  if (!user) return res.status(404).json({ error: "user not found" });
  res.json(user);
});

module.exports = router;
